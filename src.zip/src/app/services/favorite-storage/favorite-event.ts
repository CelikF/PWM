export interface FavoriteEvent {
    id: number;
    userId: string;
    eventId: string;
}
